package com.lt.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringRestJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
